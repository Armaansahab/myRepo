import React from "react";

import Home from "@/components/home-14";

export const metadata = {
  title: "Home-14 || Superio - Job Borad React NextJS Template",
  description: "Superio - Job Borad React NextJS Template",
};

const index = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default index;
