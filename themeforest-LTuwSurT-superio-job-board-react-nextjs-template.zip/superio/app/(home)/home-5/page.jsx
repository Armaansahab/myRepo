import React from "react";

import Home from "@/components/home-5";

export const metadata = {
  title: "Home-5 || Superio - Job Borad React NextJS Template",
  description: "Superio - Job Borad React NextJS Template",
};

const index = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default index;
