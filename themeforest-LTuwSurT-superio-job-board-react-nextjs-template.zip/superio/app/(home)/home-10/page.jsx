import React from "react";

import Home from "@/components/home-10";

export const metadata = {
  title: "Home-10 || Superio - Job Borad React NextJS Template",
  description: "Superio - Job Borad React NextJS Template",
};

const index = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default index;
