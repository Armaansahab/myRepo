const Filter = () => {
  return (
    <select>
      <option value="">All Categories</option>
      <option value="44">Accounting / Finance</option>
      <option value="106">Automotive Jobs</option>
      <option value="46">Customer</option>
      <option value="48">Design</option>
      <option value="47">Development</option>
      <option value="45">Health and Care</option>
      <option value="105">Marketing</option>
      <option value="107">Project Management</option>
    </select>
  );
};

export default Filter;
